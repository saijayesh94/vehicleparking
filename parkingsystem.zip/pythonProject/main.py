import csv
import tkinter as tk
from itertools import count
from tkinter import ttk
from tkinter import messagebox
from time import gmtime, strftime
from pathlib import Path
import os
import csv

root1 = tk.Tk()
root1.title("login form")
root1.geometry('800x500')
root1.configure(bg='#333333')

def update_index(vi,fadd):
    with open(str(vi)+"-index.txt","w",newline="") as index_file:
        writer=csv.writer(index_file)
        writer.writerow([vi,fadd])

def login():
    username = ""
    password = ""
    if usr_entry.get() == username and pass_entry.get() == password:
        # print("login successful");

        window = tk.Tk()
        window.title("new page")
        window.geometry('500x400')
        window.configure(bg='#333333')

        def vi_page():
            home_frame = tk.Frame(inframe)
            lb = tk.Label(home_frame, text='vehicle number:', font=('Calabri', 10), fg="#FF3399")
            # lb.pack(side=tk.LEFT, pady=60)
            lb.grid(row=1, column=0)
            vi_entry = tk.Entry(home_frame, font="Calibri 10")
            # vi_entry.insert(0, "enter vehicle number")
            # vi_entry.pack(side=tk.LEFT, padx=10, pady=60)
            vi_entry.grid(row=1, column=1, pady=20)
            vi = vi_entry
            time = str(strftime("[%Y-%m-%d] [%H:%M:%S]", gmtime()))
            but1 = tk.Button(home_frame, text='Submit', command=lambda: write(str(vi.get().strip()), time))
            but1.grid(row=2, column=1)

            def write(vi_no, time):
                global vh

                f1 = open(str(vi_no) + ".txt", "a")
                f1.write("vehicle in:")
                f1.write(vi_no + "\t")
                f1.write(time + "\n")
                vh = vi_no
                f1.close()
                file_name = str(vi_no) + ".txt"
                fadd = id(file_name)
                print(fadd)
                update_index(vi_no, fadd)

                messagebox.showerror("hi welcome")
                return

            home_frame.pack(pady=20)

        def vp_page():
            vp_frame = tk.Frame(inframe)
            path = Path('C:/Users/my/PycharmProjects/pythonProject/')

            def count_text_files(path):
                count = 0

                for file_name in os.listdir(path):
                    file_path = os.path.join(path, file_name)

                    if os.path.isfile(file_path) and file_name.endswith('.txt') and not file_name.endswith('-index.txt'):
                        count += 1

                return count

            tvp = count_text_files(path)
            print(tvp)

            canvas = tk.Canvas(vp_frame, width=1000, height=750, bg="#FFFFFF")

            # Add a text in Canvas
            canvas.create_text(50, 50, text="                    Total Vehicle parked:" + str(tvp), fill="black", font=('Helvetica 15 bold'))
            canvas.pack()
            vp_frame.pack()

        def vd_page():
            def display():
                vi = vd_entry.get().strip()  # Get the value from the entry field
                try:
                    with open(vi + ".txt", "r") as file:
                        content = file.read()
                        display_text.config(text=content)  # Update the label with the file content
                except FileNotFoundError:
                    display_text.config(text="File not found")  # Display an error message if the file is not found

            vd_frame = tk.Frame(inframe)

            vd_label = tk.Label(vd_frame, text='Enter vehicle number', fg="#FF3399")
            vd_label.grid(row=0, column=0, pady=10)

            vd_entry = tk.Entry(vd_frame, font=('Calibri', 10))
            vd_entry.grid(row=0, column=1, pady=10)

            display_button = tk.Button(vd_frame, text="Display File", command=display)
            display_button.grid(row=1, column=0, columnspan=2, pady=10)

            display_text = tk.Label(vd_frame, anchor="w", relief="raised")
            display_text.grid(row=2, column=0, columnspan=2, pady=10)

            vd_frame.pack()

        def vo_page():

            home_frame = tk.Frame(inframe)
            lb = tk.Label(home_frame, text='vehicle number:', font=('Calabri', 10), fg="#FF3399")

            lb.grid(row=1, column=0)
            vi_entry = tk.Entry(home_frame, font="Calibri 10")

            vi_entry.grid(row=1, column=1, pady=20)
            vi = vi_entry
            time = str(strftime("[%Y-%m-%d] [%H:%M:%S]", gmtime()))

            but1 = tk.Button(home_frame, text='Submit', command=lambda: write(str(vi.get().strip()), time))
            but1.grid(row=2, column=1)

            def write(vi_no, time):
                global vh

                f1 = open(str(vi_no) + ".txt", "a")
                f1.write("vehicle out:")
                f1.write(vi_no + "\t")
                f1.write(time + "\n")
                vh = vi_no
                f1.close()
                file_name=str(vi_no)+".txt"
                fadd=id(file_name)
                print(fadd)
                update_index(vi_no,fadd)
                file_name.close()
                messagebox.showerror("hi welcome")
                return

            home_frame.pack(pady=20)

        def hide_indicators():
            ovibutton_indicater.config(bg='#333333')
            ovpbutton_indicater.config(bg='#333333')
            ovdbutton_indicater.config(bg='#333333')
            ovobutton_indicater.config(bg='#333333')

        def delete_page():
            for frame in inframe.winfo_children():
                frame.destroy()

        def indicate(lb, page):
            hide_indicators()
            lb.config(bg="#FF3399")
            delete_page()
            page()

        option_frame = tk.Frame(window, bg='#333333')
        # ilabel=tk.Label(window,text='welcome to vehicle paking',foreground="#FF3399",background="#333333",font=("Calibri 25"))
        # ilabel.pack()
        ovibutton = tk.Button(window, text='vehicles_in', font=('Calabri', 10), foreground="#FF3399",
                              background="#333333", bd=0, command=lambda: indicate(ovibutton_indicater, vi_page))
        ovibutton.place(x=10, y=50)
        ovibutton_indicater = tk.Label(option_frame, text='', bg="#333333")
        ovibutton_indicater.place(x=3, y=50, width=4, height=30)

        ovpbutton = tk.Button(window, text='vehicles_parked', font=('Calabri', 10), foreground="#FF3399",
                              background="#333333", bd=0, command=lambda: indicate(ovpbutton_indicater, vp_page))
        ovpbutton.place(x=10, y=125)
        ovpbutton_indicater = tk.Label(option_frame, text='', bg="#333333")
        ovpbutton_indicater.place(x=3, y=125, width=4, height=30)

        ovdbutton = tk.Button(window, text='vehicles_details', font=('Calabri', 10), foreground="#FF3399",
                              background="#333333", bd=0, command=lambda: indicate(ovdbutton_indicater, vd_page))
        ovdbutton.place(x=10, y=200)
        ovdbutton_indicater = tk.Label(option_frame, text='', bg="#333333")
        ovdbutton_indicater.place(x=3, y=200, width=4, height=30)

        ovobutton = tk.Button(window, text='vehicles_out', font=('Calabri', 10), foreground="#FF3399",
                              background="#333333", bd=0, command=lambda: indicate(ovobutton_indicater, vo_page))
        ovobutton.place(x=10, y=275)
        ovobutton_indicater = tk.Label(option_frame, text='', bg="#333333")
        ovobutton_indicater.place(x=3, y=275, width=4, height=30)

        option_frame.pack(side=tk.LEFT)
        option_frame.pack_propagate(False)
        option_frame.configure(width=120, height=400)

        inframe = tk.Frame(window, highlightbackground='black', highlightthickness=1)

        inframe.pack(side=tk.LEFT)
        inframe.pack_propagate(False)
        inframe.configure(width=400, height=500)



    else:
        # print("invalin login");
        messagebox.showerror('login', 'invalid details')


root = tk.Frame(bg='#333333')

# input
label = ttk.Label(root, text='Login', foreground="#FF3399", background="#333333", font=("Calibri 25"))
usr_label = tk.Label(root, text='username:', foreground="#FFFFFF", background="#333333", font="Calibri 16")
usr_entry = tk.Entry(root, font="Calibri 16")
pass_label = tk.Label(root, text='password:', foreground="#FFFFFF", background="#333333", font="Calibri 16")
pass_entry = tk.Entry(root, show="*", font="Calibri 16")
log_button = tk.Button(root, text="login", foreground="#FFFFFF", background="#FF3399", font="Calibri 16", command=login)

# pack
label.grid(row=0, column=0, columnspan=2, pady=30)
usr_label.grid(row=1, column=0, pady=10, padx=5)
usr_entry.grid(row=1, column=1, pady=20)
pass_label.grid(row=2, column=0, pady=20)
pass_entry.grid(row=2, column=1)
log_button.grid(row=3, column=0, columnspan=2, pady=30)

root.pack()
root.mainloop()
